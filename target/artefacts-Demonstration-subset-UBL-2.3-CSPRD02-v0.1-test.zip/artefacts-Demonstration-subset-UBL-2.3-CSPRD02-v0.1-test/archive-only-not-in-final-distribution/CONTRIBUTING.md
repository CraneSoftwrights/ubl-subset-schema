# Repository Contributions, Participation, and Public Access

**Who may Contribute?** Anyone may contribute for consideration provided permission to freely use their contribution is made in writing to [Crane's Administrator](mailto:info@CraneSoftwrights.com) with the expectation that the results are public and may be freely used by others.

**Use of Contributions.**  Content placed into this 
GitHub repository is visible and publicly accessible.

**Cloning and forking.** This repository may be cloned and forked for use by any party. 

Please see [README](https://github.com/oasis-tcs/ubl-2.3-artefacts/blob/master/README.md) for 
general description of this repository.
